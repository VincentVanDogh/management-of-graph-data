import { Component, ElementRef, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Network } from 'vis-network';

@Component({
 selector: 'app-rdf',
  templateUrl: './rdf.component.html',
  styleUrls: ['./rdf.component.scss']
})
export class RdfComponent {

  @ViewChild('graphContainer', { static: true })
  graphContainer!: ElementRef;

  constructor(private http: HttpClient) {}

 loadGraph() {
  this.http.get<any>('/graph').subscribe({
    next: (data) => {
      const nodes = new (window as any).vis.DataSet(
        data.nodes.map((n: any) => ({
          id: n.id,
          label: n.id.split('/').pop()
        }))
      );

      const edges = new (window as any).vis.DataSet(
        data.edges.map((e: any) => ({
          from: e.source,
          to: e.target,
          label: e.label.split('/').pop(),
          arrows: 'to'
        }))
      );

      const networkData = { nodes, edges };
      new Network(this.graphContainer.nativeElement, networkData, {
        edges: { arrows: { to: true } },
        physics: { enabled: true }
      });
    },
    error: (err) => console.error('Graph load error', err)
  });
}

}
