import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Network, Node, Edge } from 'vis-network';
import { DataSet } from 'vis-data';

@Component({
  selector: 'app-rdf',
  templateUrl: './rdf.component.html',
  styleUrls: ['./rdf.component.scss']
})
export class RdfComponent implements AfterViewInit {

  @ViewChild('graphContainer') graphContainer!: ElementRef;
  network!: Network;

  query: string = ''; // user will write SPARQL query here

  constructor(private http: HttpClient) {}

  ngAfterViewInit() {
    console.log('Graph container initialized');
  }

  // Load full graph if needed
  loadGraph() {
    this.http.get<any>('http://127.0.0.1:5000/graph').subscribe(
      data => this.renderGraph(data),
      err => console.error('Error loading graph', err)
    );
  }

  // Run user-defined SPARQL query
  runQuery() {
    if (!this.query.trim()) {
      alert('Please enter a SPARQL query');
      return;
    }

    this.http.post<any>('http://127.0.0.1:5000/query', { query: this.query }).subscribe(
      data => this.renderGraph(data),
      err => {
        console.error('Error running query', err);
        alert('Error: ' + (err.error?.error || 'Check your SPARQL query'));
      }
    );
  }

  // Render graph using vis-network
  renderGraph(data: any) {
    if (!data || !data.nodes || !data.edges) {
      console.error('Invalid graph data:', data);
      return;
    }

    const nodes = new DataSet<Node>(
      data.nodes.map((n: any) => ({
        id: n.id,
        label: n.id.split('/').pop(), // can be improved to use actual names if provided
        shape: 'dot',
        size: 10,
        font: { size: 12 }
      }))
    );

    const edges = new DataSet<Edge>(
      data.edges.map((e: any) => ({
        from: e.source,
        to: e.target,
        arrows: 'to',
        label: e.label ? e.label.split('/').pop() : ''
      }))
    );

    if (this.network) {
      this.network.setData({ nodes, edges });
      return;
    }

    this.network = new Network(
      this.graphContainer.nativeElement,
      { nodes, edges },
      {
        layout: { improvedLayout: false },
        physics: {
          enabled: true,
          barnesHut: {
            gravitationalConstant: -3000,
            springLength: 150,
            damping: 0.2
          },
          stabilization: { iterations: 200, fit: true }
        },
        edges: { arrows: { to: true }, smooth: true, font: { align: 'middle' } },
        interaction: { hover: true, tooltipDelay: 100 }
      }
    );

    this.network.once('stabilized', () => {
      this.network.setOptions({ physics: false });
    });
  }
}
